import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'empty-project';
  CountryData:any=["india","Shrilanka","Africa","UAES","abc","scjhkl"]

}
