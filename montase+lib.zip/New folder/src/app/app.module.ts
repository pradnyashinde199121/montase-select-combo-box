import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MyLibModule } from 'pradnya-lib';
import { SarthiSelectComponent } from './sarthi-select/sarthi-select.component';
import { FormsModule } from '@angular/forms';
import { MentoasComponent } from './mentoas/mentoas.component';
import { DatePipe } from '@angular/common';
import {MatInputModule} from '@angular/material/input';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
@NgModule({
  declarations: [
    AppComponent,
    SarthiSelectComponent,
    MentoasComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MyLibModule,
    FormsModule,
    BrowserAnimationsModule,
    MatInputModule
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
