import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SarthiSelectComponent } from './sarthi-select/sarthi-select.component';
import { MentoasComponent } from './mentoas/mentoas.component';
const routes: Routes = [
  {path:'sarthi-select', component: SarthiSelectComponent},
  {path:'mentoas', component: MentoasComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
