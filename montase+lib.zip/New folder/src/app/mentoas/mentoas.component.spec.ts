import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentoasComponent } from './mentoas.component';

describe('MentoasComponent', () => {
  let component: MentoasComponent;
  let fixture: ComponentFixture<MentoasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentoasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentoasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
