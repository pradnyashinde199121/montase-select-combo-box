import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-mentoas',
  templateUrl: './mentoas.component.html',
  styleUrls: ['./mentoas.component.css']
})

export class MentoasComponent implements OnInit {
 data:any=[{id:1 ,img:"assets/Images/shop-charcole-black.jpg",time:"May 26, 2020, 3:54 PM"},
            {id:2 , img:"assets/Images/shop-golden-sunset.jpg", time:"May 26, 2020, 3:55 PM"},
            {id:3 , img:"assets/Images/shop-mint-green.jpg",time:"May 26, 2020, 3:56 PM"},
            {id:4 , img:"assets/Images/shop-pink-modern.jpg",time:"May 26, 2020, 3:57 PM"},
            {id:5 , img:"assets/Images/shop-pink.jpg",time:"May 26, 2020, 4:43 PM"},
            {id:6 , img:"assets/Images/shop-purple-berry.jpg",time:"May 26, 2020, 3:52 PM"}];

            myDate:any = new Date();
            displyImg:any;
            dateTime:any;
            data1:any=[];
            dataJson:any={};
            name:any;
  constructor(private datePipe: DatePipe) { 
    this.myDate = this.datePipe.transform(this.myDate, "MMM d, y, h:mm a");
  }

  ngOnInit(): void {
    
    this.myDate=new Date();
    this.myDate = this.datePipe.transform(this.myDate, "MMM d, y, h:mm a");
    this.data.forEach(x => {

     if (x.time == this.myDate){
      //  alert("value match");
       this.displyImg=x.img;
     }
    //  else{
    //    alert("not match");
    //  }
      
    });
   
  
    
  }

  addData(){
    this.dataJson={};
    this.dataJson.name=this.name;
    this.dateTime= this.datePipe.transform(this.dateTime, "MMM d, y, h:mm a");
    this.dataJson.time=this.dateTime;
    this.data1.push(this.dataJson);
    this.name='';
    this.dateTime='';
  }

 
}
