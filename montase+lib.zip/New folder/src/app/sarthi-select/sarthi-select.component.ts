import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sarthi-select',
  templateUrl: './sarthi-select.component.html',
  styleUrls: ['./sarthi-select.component.css']
})
export class SarthiSelectComponent implements OnInit {
  CountryData:any = [{id:1, name:"india"},
  {id:2, name:"Shrilanka"},
  {id:3, name:"Africa"},
  {id:4, name:"USA"},
  {id:5, name:"UAE"},
  {id:6, name:"NewZland"}
  ]
    // CountryData:any = ["india","Shrilanka","Africa","USA","UAE","NewZland"]
 addedData:any=[];
 SelectedCountry:any = {};
 SelectedCountry1:any= {};
  constructor() { }

  ngOnInit(): void {

  }
  addValue(){
   const index= this.addedData.indexOf(this.SelectedCountry[0].name)
    if(index === -1)
    {
      this.addedData.push(this.SelectedCountry[0].name);
    }
    else
    {
    alert("Already Added");
    }
  }
  removeValue(){
    const index = this.addedData.indexOf(this.SelectedCountry1[0]);
    this.addedData.splice(index,1);
  }

}
